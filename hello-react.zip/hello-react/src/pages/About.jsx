import React from "react";
import { useNavigate } from "react-router-dom";
import Home from "./Home";
import './About.css'; // optional CSS for styling

function About() {
  const navigate = useNavigate();

  return (
    <div className="about-page">
      <Home />
      

      <div className="about-content">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/RaNy4JreNPs?si=PLXnvKDCUb5bsvjs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        <h1>About Us</h1>
        <p>
          Welcome to our website! We are committed to providing the best services
          and information to our users. Our team is passionate about delivering
          quality solutions and creating a seamless experience for everyone.
        </p>
        <p>
          Our mission is to innovate, educate, and connect with our audience in
          meaningful ways. We constantly strive to improve and adapt to the
          latest trends and technologies.
        </p>

        <h2>Our Values</h2>
        <ul>
          <li>Integrity and Transparency</li>
          <li>Innovation and Creativity</li>
          <li>Customer Satisfaction</li>
          <li>Continuous Learning</li>
        </ul>
        

        
      </div>
    </div>
  );
}

export default About;
