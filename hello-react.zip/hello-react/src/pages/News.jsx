import React from "react";
import { useNavigate } from "react-router-dom";
import "./News.css";
import Home from "./Home";

function News() {
  return (
    <>
      <Home />
      <div className="news-container">
        <h1>Latest News</h1>

        <div className="news-list">
          <div className="news-item">
            <h2>React 19 Released</h2>
            <p className="news-date">2025-09-25</p>
            <p>
              React 19 introduces new hooks and improved performance for large-scale
              apps.
            </p>
          </div>

          <div className="news-item">
            <h2>Web Development Trends 2025</h2>
            <p className="news-date">2025-09-20</p>
            <p>
              Stay updated with the latest trends in web development, from AI integration
              to advanced styling techniques.
            </p>
          </div>

          <div className="news-item">
            <h2>New Features in JavaScript</h2>
            <p className="news-date">2025-09-18</p>
            <p>
              JavaScript continues evolving with new syntax and APIs to improve developer
              experience.
            </p>
          </div>
        </div>

        <button className="back-btn" onClick={() => window.history.back()}>
          Go Back
        </button>
      </div>
    </>
  );
}

export default News;
