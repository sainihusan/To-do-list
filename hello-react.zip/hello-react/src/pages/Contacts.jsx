import React from "react";
import Home from "./Home";
import './Contacts.css'; 

function Contacts() {
  return (
    <>
      <Home />
      <div className="contacts-container">
        <h1>Contact Us</h1>
        <p>We would love to hear from you! Fill out the form below or reach us directly.</p>

        <form className="contact-form">
          <label>
            Name:
            <input type="text" placeholder="Your Name" />
          </label>

          <label>
            Email:
            <input type="email" placeholder="Your Email" />
          </label>

          <label>
            Message:
            <textarea placeholder="Your Message"></textarea>
          </label>

          <button type="submit">Send Message</button>
        </form>

        <div className="contact-info">
          <h2>Our Contact Info</h2>
          <p>Email: info@example.com</p>
          <p>Phone: +91 123-456-7890</p>
          <p>Address: 123 Main Street, City, Country</p>
        </div>
      </div>
    </>
  );
}

export default Contacts;
