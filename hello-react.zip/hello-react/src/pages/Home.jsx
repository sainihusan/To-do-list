import React from "react";
import "./Home.css"; // import CSS here

function Home() {
  return (
    <div className="home-page">
      <nav>
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/News">News</a></li>
          <li><a href="/Contacts">Contact</a></li>
          <li><a href="/About">About</a></li>
        </ul>
      </nav>

      <header className="hero-section">
        <h1>Welcome to Our Website</h1>
        <p>
          Discover the latest news, updates, and insights from our team. 
          We are here to provide quality content and services for our visitors.
        </p>
        <a href="/News" className="hero-btn">Read News</a>
      </header>

      <section className="home-content">
        <h2>Our Mission</h2>
        <p>
          Our mission is to provide a seamless and informative experience 
          for everyone. We focus on delivering quality, innovation, and 
          reliability in everything we do.
        </p>

        <h2>Why Choose Us?</h2>
        <ul>
          <li>Expert Team</li>
          <li>Reliable Information</li>
          <li>Engaging Content</li>
          <li>Continuous Updates</li>
        </ul>
      </section>
    </div>
  );
}

export default Home;
