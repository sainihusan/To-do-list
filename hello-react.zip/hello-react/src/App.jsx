import { useState } from "react"
import React from "react"
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from './pages/Home'
import News from './pages/News'
import Contacts from "./pages/Contacts";
import About from "./pages/About"

const App =()=>{
    return (
        <Routes>
            
           
            <Route path="/" element={<Home />} />
             <Route path="news" element={<News />} />
             <Route path="Contacts" element={<Contacts />} />
             <Route path="About" element={<About />} />
            
        </Routes>
        

    )
    
}


export default App;
